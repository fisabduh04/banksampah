<?php

namespace App\Filament\Imports;

use App\Models\WastePrice;
use App\Models\WasteType;
use Carbon\Carbon;
use Filament\Actions\Imports\Exceptions\RowImportFailedException;
use Filament\Actions\Imports\ImportColumn;
use Filament\Actions\Imports\Importer;
use Filament\Actions\Imports\Models\Import;
use Illuminate\Support\Number;

class WastePriceImporter extends Importer
{
    /**
     * Model teknis untuk fitur Harga Bahan.
     */
    protected static ?string $model = WastePrice::class;

    /**
     * Format impor:
     *
     * Kode Bahan | Nama Bahan | Harga |
     * Berlaku Mulai | Berlaku Sampai | Aktif
     *
     * Pencocokan dilakukan berdasarkan Kode Bahan.
     * Nama Bahan hanya sebagai informasi bagi user.
     */
    public static function getColumns(): array
    {
        return [
            /**
             * Kode Bahan digunakan untuk mencari
             * Jenis Bahan pada master.
             */
            ImportColumn::make('waste_type_code')
                ->label('Kode Bahan')
                ->exampleHeader('Kode Bahan')
                ->example('LGM-BSI')
                ->requiredMapping()
                ->guess([
                    'Kode Bahan',
                    'waste_type_code',
                ])
                ->rules([
                    'required',
                    'max:255',
                ])

                /**
                 * Penting:
                 * waste_type_code bukan kolom database.
                 *
                 * Nilai ini diterjemahkan menjadi
                 * waste_type_id.
                 */
                ->fillRecordUsing(
                    function (WastePrice $record, $state): void {
                        $kodeBahan = trim((string) $state);

                        $jenisBahan = WasteType::query()
                            ->where('code', $kodeBahan)
                            ->first();

                        if (! $jenisBahan) {
                            throw new RowImportFailedException(
                                "Kode Bahan [{$kodeBahan}] tidak ditemukan."
                            );
                        }

                        /**
                         * Simpan foreign key yang sebenarnya.
                         */
                        $record->waste_type_id = $jenisBahan->id;
                    }
                ),

            /**
             * Nama Bahan hanya ditampilkan agar user
             * mengetahui bahan apa yang sedang diedit.
             *
             * Nilai ini TIDAK disimpan ke tabel Harga Bahan.
             */
            ImportColumn::make('waste_type_name')
                ->label('Nama Bahan')
                ->exampleHeader('Nama Bahan')
                ->example('BESI')
                ->guess([
                    'Nama Bahan',
                    'waste_type_name',
                ])
                ->rules([
                    'nullable',
                    'max:255',
                ])

                /**
                 * Sengaja tidak menyimpan apa pun.
                 *
                 * Nama Bahan hanya informasi pada CSV.
                 */
                ->fillRecordUsing(
                    function (WastePrice $record, $state): void {
                        // Tidak perlu disimpan ke database.
                    }
                ),

            /**
             * Harga beli bahan.
             */
            ImportColumn::make('price')
                ->label('Harga')
                ->exampleHeader('Harga')
                ->example('3000')
                ->requiredMapping()
                ->guess([
                    'Harga',
                    'price',
                ])
                ->numeric()
                ->rules([
                    'required',
                    'numeric',
                    'min:0',
                ]),

            /**
             * Tanggal mulai harga berlaku.
             */
            ImportColumn::make('effective_from')
                ->label('Berlaku Mulai')
                ->exampleHeader('Berlaku Mulai')
                ->example('2026-09-11')
                ->requiredMapping()
                ->guess([
                    'Berlaku Mulai',
                    'effective_from',
                ])
                ->castStateUsing(
                    fn ($state) => Carbon::parse($state)->toDateString()
                )
                ->rules([
                    'required',
                    'date',
                ]),

            /**
             * Tanggal akhir harga berlaku.
             *
             * Boleh kosong jika harga masih berlaku.
             */
            ImportColumn::make('effective_until')
                ->label('Berlaku Sampai')
                ->exampleHeader('Berlaku Sampai')
                ->example('2026-12-31')
                ->guess([
                    'Berlaku Sampai',
                    'effective_until',
                ])
                ->castStateUsing(
                    fn ($state) => blank($state)
                        ? null
                        : Carbon::parse($state)->toDateString()
                )
                ->rules([
                    'nullable',
                    'date',
                ]),

            /**
             * Status:
             * 1 = aktif
             * 0 = tidak aktif
             */
            ImportColumn::make('is_active')
                ->label('Aktif')
                ->exampleHeader('Aktif')
                ->example('1')
                ->requiredMapping()
                ->guess([
                    'Aktif',
                    'is_active',
                ])
                ->boolean()
                ->rules([
                    'required',
                    'boolean',
                ]),
        ];
    }

    /**
     * Menentukan record Harga Bahan yang akan dibuat
     * atau diperbarui.
     *
     * Kombinasi:
     * - Kode Bahan
     * - Berlaku Mulai
     *
     * menjadi identitas harga.
     */
    public function resolveRecord(): WastePrice
    {
        $kodeBahan = trim(
            (string) $this->data['waste_type_code']
        );

        /**
         * Cari master Jenis Bahan berdasarkan kode.
         */
        $jenisBahan = WasteType::query()
            ->where('code', $kodeBahan)
            ->first();

        /**
         * Jika kode tidak ada di master Jenis Bahan,
         * hanya baris tersebut yang gagal.
         */
        if (! $jenisBahan) {
            throw new RowImportFailedException(
                "Kode Bahan [{$kodeBahan}] tidak ditemukan."
            );
        }

        /**
         * Normalisasi tanggal.
         */
        $tanggalMulai = Carbon::parse(
            $this->data['effective_from']
        )->toDateString();

        /**
         * Jika harga dengan bahan dan tanggal yang sama
         * sudah ada, data diperbarui.
         *
         * Jika belum ada, dibuat record baru.
         */
        return WastePrice::firstOrNew([
            'waste_type_id' => $jenisBahan->id,
            'effective_from' => $tanggalMulai,
        ]);
    }

    /**
     * Notifikasi hasil impor.
     */
    public static function getCompletedNotificationBody(
        Import $import
    ): string {
        $body = 'Impor data Harga Bahan selesai. '
            .Number::format($import->successful_rows)
            .' baris berhasil diimpor.';

        if ($failedRowsCount = $import->getFailedRowsCount()) {
            $body .= ' '
                .Number::format($failedRowsCount)
                .' baris gagal diimpor.';
        }

        return $body;
    }
}
